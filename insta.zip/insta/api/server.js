var app = require('./config/server')

var port = 8080;

app.listen(port);

console.log('Servidor HTTP esta escutando na porta ' + port);


