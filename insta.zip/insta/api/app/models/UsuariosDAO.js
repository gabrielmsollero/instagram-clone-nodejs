function UsuariosDAO(connection){
    this._connection = connection();
}

UsuariosDAO.prototype.inserirUsuario = function(usuario, callback) {
    var statusCode = 200;
    this._connection.open(function(err, mongoclient) {
        if(mongoclient == undefined){
            statusCode = 500;
        } else {
            mongoclient.collection('usuarios', function(err, collection) {
                
                collection.insert(usuario);
    
                mongoclient.close();
            });
        }
        callback(statusCode);
    });
}

UsuariosDAO.prototype.autenticar = function(usuario, callback) {
    var autorizado = false;

    this._connection.open(function(err, mongoclient) {
        mongoclient.collection('usuarios', function(err, collection) {

            collection.find(usuario).toArray(function(err, result) {
                if(result[0] != undefined){
                    autorizado = true;
                }

                callback(autorizado);
            }); // o formato do JSON usuario é identico ao da query.

            mongoclient.close();
        })
    });
}

module.exports = function() {
    return UsuariosDAO;
}