var fs = require('fs');

function PostagemDAO(connection) {
    this._connection = connection();
}

module.exports = function() {
    return PostagemDAO;
}