module.exports = function(application){
    application.post('/api', function(req, res){
        application.app.controllers.feed.postarFoto(application, req, res);
    });

    application.get('/api', function(req, res){
        application.app.controllers.feed.feed(application, req, res);
    });

    application.get('/api/:id', function(req, res){
        application.app.controllers.feed.postagem(application, req, res);
    });

    application.put('/api/:id', function(req, res){
        application.app.controllers.feed.comentar(application, req, res);
    });

    application.delete('/api/:id', function(req, res){
        application.app.controllers.feed.excluirComentario(application, req, res);
    });

    application.get('/imagens/:imagem', function(req, res){
        application.app.controllers.feed.buscarImagem(application, req, res);
    });
    
    application.post('/cadastrar_usuario', function(req, res){
        application.app.controllers.cadastro.cadastrarUsuario(application, req, res);
    });

    application.post('/autenticar', function(req, res){
        application.app.controllers.cadastro.autenticar(application, req, res);
    });

    application.get('/usuario/:usuario', function(req, res){
        application.app.controllers.feed.buscarUsuario(application, req, res);
    });
}