module.exports.cadastrarUsuario = function(app, req, res) {
    var usuario = req.body;

    var connection = app.config.dbConnection;

    var UsuariosDAO = new app.app.models.UsuariosDAO(connection);
    UsuariosDAO.inserirUsuario(usuario, function(statusCode) {
        res.status(statusCode).json({});
    });
}

module.exports.autenticar = function(app, req, res) {
   var usuario = req.body;

   var connection = app.config.dbConnection;

   var UsuariosDAO = new app.app.models.UsuariosDAO(connection);

   UsuariosDAO.autenticar(usuario, function(autorizado){
       res.json({autorizado: autorizado});
   });

}