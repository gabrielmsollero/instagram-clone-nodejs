var http = require('http'),
	crypto = require('crypto');

module.exports.index = function(application, req, res){
	var msg = req.query.msg
	res.render('index/padrao', {msg: msg, erros: []});
}

module.exports.cadastro = function(application, req, res){
	res.render('index/cadastro', {erros: []});
}

module.exports.cadastrar = function(application, req, res){
	dadosForm = req.body;
	
	req.assert('usuario', 'Usuário não pode ser vazio.').notEmpty();
	req.assert('senha', 'Senha não pode ser vazio.').notEmpty();
	
	var erros = req.validationErrors();

	if(erros){
		res.render('index/cadastro', {erros: erros});
	} else {

		dadosForm.senha = crypto.createHash('md5').update(dadosForm.senha).digest('hex'); 
		// fazer requisiçao para o servidor para a API para cadastrar usuario
		var options = {
			hostname: 'localhost',
			port: 8080,
			path: '/cadastrar_usuario',
			method: 'post',
			headers: { // front e back end só se comunicam via json
				'Accept': 'application/json',
				'Content-type': 'application/json'
			}
		}

		var msg = 'A';

		var req = http.request(options, function(response){

			if(response.statusCode != 200) {
				msg = 'B';
			}
			
			res.redirect('/?msg=' + msg);

		});

		req.write(JSON.stringify(dadosForm));
		req.end();

		// Se obtiver sucesso, executar comando abaixo, senao renderizar com erro de "Não foi possivel cadastrar"
	}
}

module.exports.autenticar = function(app, req, res){
	
	var dadosForm = req.body;

    req.assert('usuario', 'Usuário não pode ser vazio').notEmpty();
    req.assert('senha', 'Senha não pode ser vazio').notEmpty();

    var erros = req.validationErrors();

    if(erros){
        res.render('index/padrao', {erros: erros, msg: ''});
        return;
    } else {
		dadosForm.senha = crypto.createHash('md5').update(dadosForm.senha).digest('hex'); 
		// fazer requisiçao para o servidor para a API para cadastrar usuario
		var options = {
			hostname: 'localhost',
			port: 8080,
			path: '/autenticar',
			method: 'post',
			headers: { // front e back end só se comunicam via json
				'Accept': 'application/json',
				'Content-type': 'application/json'
			}
		}

		var buffer_corpo_response = [];
		var autorizado = false;

		var request = http.request(options, function(response){
			response.on('data', function(chunk) {
				buffer_corpo_response.push(chunk);
			});
		
			response.on('end', function() {
				var corpo_response = JSON.parse(Buffer.concat(buffer_corpo_response).toString());
				autorizado = corpo_response.autorizado;

				if(response.statusCode != 200){
					res.redirect('/?msg=C');
				} else {
					if(autorizado) {
						req.session.autorizado = true;
						req.session.usuario = dadosForm.usuario;
						res.redirect('home');
					} else {
						res.redirect('/?msg=D');
					}
				}
			});
		});

		request.write(JSON.stringify(dadosForm));
		request.end();
	}

    // var connection = application.config.dbConnection;
    // UsuariosDAO = new application.app.models.UsuariosDAO(connection);

	// UsuariosDAO.autenticar(dadosForm, req, res);
	
	// enviar usuario e senha pro back end para ele executar os 3 comandos acima
}
