var http = require('http');

module.exports.home = function(application, req, res){
	if(req.session.autorizado){
		res.render('home/padrao', {usuario: req.session.usuario});
	} else {
		res.send('Usuário precisa fazer login');
	}

}

module.exports.buscar = function(application, req, res){
	var usuario = req.body.usuario;

	var options = {
		hostname: 'localhost',
		port: 8080,
		path: '/usuario/' + usuario,
		method: 'get',
		headers: { // front e back end só se comunicam via json
			'Accept': 'application/json',
			'Content-type': 'application/json'
		}
	}

	var buffer_corpo_response = [];

	var request = http.request(options, function(response){
		response.on('data', function(chunk) {
			buffer_corpo_response.push(chunk);
		});
	
		response.on('end', function() {
			var corpo_response = JSON.parse(Buffer.concat(buffer_corpo_response).toString());
			res.render('home/user', {usuario: req.session.usuario, postagens: corpo_response});
		});
	});

	request.end();
}